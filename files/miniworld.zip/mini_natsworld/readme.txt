Nat's Mini World

This is a narrowed-down version of the Nat's World game I wrote for my son.
It has all of the code and logic of the full version, but only a fraction
of the pictures, and with low picture quality, to keep the download size 
reasonable.

You'll need:
  - Python (www.python.org, or www.activestate.com/python), and
  - pygame (www.pygame.org)

To run the game, execute main.py.  You can move around the school environment
by clicking on the left, right, or middle of the screen.

I've attempted to structure the code so that it could be reused for
other environments, although only one environment has ever been built,
so that attempt has not been tested.

If you have any questions, feel free to email me: ned@nedbatchelder.com

Enjoy.

Ned Batchelder
http://www.nedbatchelder.com
