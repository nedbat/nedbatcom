# This file is part of Platitude

""" The Platitude setup script.
"""

__name__ = 'Platitude'
__description__ = 'Platitude lattice maker'
__copyright__ = 'Copyright 2005, Ned Batchelder, All rights reserved.'
__author__ = 'Ned Batchelder'
__author_email__ = 'ned@nedbatchelder.com'
__url__ = 'http://nedbatchelder.com/code/platitude'
__revision__ = '$Rev: 36 $'

from distutils.core import setup
import glob, os, py2exe, sys

sys.path.append('src')

from Platitude import __version__

manifest_template = '''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">
    <assemblyIdentity
        version="5.0.0.0"
        processorArchitecture="x86"
        name="%(__name__)s"
        type="win32"
    />
    <description>%(__description__)s</description>
    <dependency>
        <dependentAssembly>
            <assemblyIdentity
                type="win32"
                name="Microsoft.Windows.Common-Controls"
                version="6.0.0.0"
                processorArchitecture="X86"
                publicKeyToken="6595b64144ccf1df"
                language="*"
            />
        </dependentAssembly>
    </dependency>
</assembly>
'''

RT_MANIFEST = 24

program = dict(
    name = __name__,
    description = __description__,
    version = __version__,
    company_name = __author__,
    copyright = __copyright__,
    script = "src/Platitude.py",
    other_resources = [
        (RT_MANIFEST, 1, manifest_template % globals())
        ],
    icon_resources = [
        (1, "src/platitude.ico")
        ]
    )

includes = ["encodings.utf_8"]
excludes = ["smtplib"]

setup(
    name = __name__,
    version = __version__,
    url = __url__,
    author = __author__,
    author_email = __author_email__,
    # targets to build
    windows = [ program ],
    data_files = [
        ('.', glob.glob('src/*.ico')),
        ],
    options = {"py2exe": {
                # create a compressed zip archive
                "compressed": 1,
                "optimize": 2,
                "includes": includes,
                "excludes": excludes,
        }}
    )
