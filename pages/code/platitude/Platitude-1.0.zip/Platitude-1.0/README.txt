This is the Platitude lattice program.

See http://nedbatchelder.com/code/platitude for details.
