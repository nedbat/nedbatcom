# This file is part of Platitude

""" The lattice data model.
"""

__copyright__ = 'Copyright 2005, Ned Batchelder, All rights reserved.'
__author__ = 'Ned Batchelder'
__revision__ = '$Rev: 28 $'

class LatModel:
    def __init__(self):
        self.gtlj = []
        self.path = ""
        self.dirty = False
        
    tiles = 'GTLJ-|IH +'

    inversions = {
        # nw corner
        'nw': ' -|+TLJJGJ',
        # ne corner
        'ne': '- +|GJLLTL',
        # sw corner'
        'sw': '|+ -JGTTLT',
        # se corner
        'se': '+|- LTGGJG',
        }

    # The direction to start going from each tile type.
    direction0 = 'esnnennn n'

    directions = {
        'n': 'ew   nnn n',
        'e': ' s ne ee e',
        's': '  ew sss s',
        'w': 's n w ww w',
        }

    def MakeHatch(self, nx, ny):
        self.gtlj = self.hatch(nx, ny)
        self.dirty = True
        
    def getSize(self):
        return (len(self.gtlj[0]), len(self.gtlj))

    size = property(getSize)
    
    def oneline(self, x, pat):
        return list(pat[:5] + (pat[5:7] * (x-2)) + pat[7:])

    def hatch(self, x, y):
        s = []
        s.append(self.oneline(x, "G-TGTGTGTG-T"))
        s.append(self.oneline(x, "| |LIHIHJ| |"))
        s.append(self.oneline(x, "L-I-HIHI-H-J"))
        s.append(self.oneline(x, "GT|GIHIHT|GT"))
        s.append(self.oneline(x, "LIHIHIHIHIHJ"))

        for i in range(y-2):
            s.append(self.oneline(x, "GHIHIHIHIHIT"))
            s.append(self.oneline(x, "LIHIHIHIHIHJ"))

        s.append(self.oneline(x, "GHIHIHIHIHIT"))
        s.append(self.oneline(x, "LJ|LHIHIJ|LJ"))
        s.append(self.oneline(x, "G-H-IHIH-I-T"))
        s.append(self.oneline(x, "| |GHIHIT| |"))
        s.append(self.oneline(x, "L-JLJLJLJL-J"))
        return s

    def InvertFour(self, x, y):
        """ Invert the square around x, y.
        """
        self.invertone(x, y, 'nw')
        self.invertone(x+1, y, 'ne')
        self.invertone(x, y+1, 'sw')
        self.invertone(x+1, y+1, 'se')
        self.FixWeave()
        self.dirty = True
        
    def tileindex(self, c):
        n = self.tiles.find(c)
        assert n >= 0
        return n
    
    def invertone(self, x, y, corner):
        c = self.gtlj[y][x]
        self.gtlj[y][x] = self.inversions[corner][self.tileindex(c)]

    def Cycle(self, x, y, d=None):
        """ Return a list of points on the cycle starting at x,y,
            going in the given direction.  If no direction is
            specified, one will be chosen.
        """
        # Choose an initial direction based on the directions we can go from here.
        c = self.gtlj[y][x]
        if not d:
            d = self.direction0[self.tileindex(c)]
            if d == ' ':
                return []
                
        # Remember our first position and direction, to detect when we've cycled.
        x0, y0, d0 = x, y, d
        
        cyc = [(x, y, d, c)]

        # Now walk along the path, until we get back to our starting point
        while 1:
            # Move to the next place
            if d == 'n':
                y -= 1
            elif d == 'e':
                x += 1
            elif d == 's':
                y += 1
            else:
                assert d == 'w'
                x -= 1

            # Figure the direction based on the old direction and the tile.
            c = self.gtlj[y][x]
            d = self.directions[d][self.tileindex(c)]

            if (x, y, d) == (x0, y0, d0):
                break

            cyc.append( (x, y, d, c) )
            
        return cyc

    def FixWeave(self):
        """ Find any + tiles, and switch them to H or I to make the weave
            right.
        """
        nplus = 0
        nguess = 0
        for y, line in enumerate(self.gtlj):
            for x, c in enumerate(line):
                if c == '+':
                    for parity, d0 in enumerate('ne'):
                        cyc = self.Cycle(x, y, d0)
                        tiles = [ (d, c) for x1, y1, d, c in cyc[1:] ]
                        nhi = 0
                        for d, c in tiles:
                            if c == '+':
                                parity += 1
                            elif c in 'HI':
                                nhi += 1
                                if d in 'ns':
                                    parity += 1
                                if c == 'I':
                                    parity += 1
                                break
                        if nhi > 0:
                            break
                    if nhi == 0:
                        nguess += 1
                        #print "Guessing at %d,%d" % (x,y)
                    # Now that we've figured out what the first spot is,
                    # make the whole cycle definite.
                    for x2, y2, d, c in cyc:
                        if c == '+':
                            nplus += 1
                            self.gtlj[y2][x2] = 'HI'[parity % 2]
                            parity += 1
                        elif c in 'IHGTJL':
                            parity += 1

        #print "FixWeave: %d plusses, %d guesses" % (nplus, nguess)

    lat3 = [
        ['GTG', 'L++', 'G++'],  # G
        ['TGT', '++J', '++T'],  # T
        ['L++', 'G++', 'LJL'],  # L
        ['++J', '++T', 'JLJ'],  # J
        ['---', '---', '---'],  # -
        ['|||', '|||', '|||'],  # |
        ['+++', '+++', '+++'],  # I
        ['+++', '+++', '+++'],  # H
        ['   ', '   ', '   '],  #
        ['+++', '+++', '+++'],  # +
        ]

    def Triplicate(self):
        """ Make the current lattice even more latticy.
        """
        orig = self.gtlj

        self.gtlj = []        
        for line in orig:
            l0 = l1 = l2 = ''
            for c in line:
                n = self.tileindex(c)
                l0 += self.lat3[n][0]
                l1 += self.lat3[n][1]
                l2 += self.lat3[n][2]
            self.gtlj += [list(l0), list(l1), list(l2)]
        self.FixWeave()
        self.dirty = True

    filesig = 'Platitude 1'
    
    def Save(self, path=None):
        if path:
            self.path = path
        f = open(self.path, 'wt')
        print >> f, self.filesig
        print >> f, "gtlj %d" % len(self.gtlj)
        for line in self.gtlj:
            print >> f, ''.join(line)
        f.close()
        self.dirty = False

    def Open(self, path):
        self.path = path
        f = open(self.path, 'rt')
        signature = f.readline()
        if signature[:-1] != self.filesig:
            raise "Bad file signature"
        cmd = f.readline().split()
        if cmd[0] == 'gtlj':
            nlines = int(cmd[1])
            self.gtlj = []
            for n in range(nlines):
                line = f.readline()
                self.gtlj.append(list(line[:-1]))
        else:
            raise "Unknown op in file: %s" % cmd[0]
        self.dirty = False
