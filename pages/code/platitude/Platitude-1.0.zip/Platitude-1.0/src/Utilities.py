# This file is part of Platitude

""" Utilities.
"""

__copyright__ = 'Copyright 2005, Ned Batchelder, All rights reserved.'
__author__ = 'Ned Batchelder'
__revision__ = '$Rev: 28 $'

import sys
import path

def getProgramDir():
    """ Return a string, the path to the directory containing the program.
    """
    
    exe = sys.executable

    # If sys.executable is python.exe, then we are running a script.
    if path.path(exe).name in ['python.exe', 'pythonw.exe']:
        # Find the name of the script from sys.argv[0], and use its directory
        # as the program directory.
        progfile = sys.argv[0]
    else:
        # The executable is something else, we've been py2exe'd.  Use its
        # directory as the program directory.
        progfile = exe

    return path.path(progfile).dirname() or '.'
