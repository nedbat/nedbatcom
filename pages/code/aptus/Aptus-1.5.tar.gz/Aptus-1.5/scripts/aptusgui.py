#!/usr/bin/env python
import aptus.gui, sys
aptus.gui.main(sys.argv[1:])
