#!/usr/bin/env python
import aptus.cmdline, sys
aptus.cmdline.main(sys.argv[1:])
