Aptus Mandelbrot explorer and renderer!
http://nedbatchelder.com/code/aptus
