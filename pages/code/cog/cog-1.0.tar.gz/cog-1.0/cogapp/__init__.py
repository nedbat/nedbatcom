""" Cog code generation tool.
    http://nedbatchelder.com/code/cog
"""

from cogapp import *

__version__ = '1.00.20040210'

# History:
# 20040210: First public version.
