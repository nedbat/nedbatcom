""" Test the cogapp.whiteutils module.
    http://nedbatchelder.com/code/cog
"""

import unittest
from whiteutils import *

class WhitePrefixTests(unittest.TestCase):
    """ Test cases for cogapp.whiteutils.
    """

    def testSingleLine(self):
        self.assertEqual(whitePrefix(['']), '')
        self.assertEqual(whitePrefix([' ']), '')
        self.assertEqual(whitePrefix(['x']), '')
        self.assertEqual(whitePrefix([' x']), ' ')
        self.assertEqual(whitePrefix(['\tx']), '\t')
        self.assertEqual(whitePrefix(['  x']), '  ')
        self.assertEqual(whitePrefix([' \t \tx   ']), ' \t \t')

class ReindentBlock(unittest.TestCase):
    """ Test cases for cogapp.reindentBlock.
    """

    def testNonTermLine(self):
        self.assertEqual(reindentBlock(''), '')
        self.assertEqual(reindentBlock('x'), 'x')
        self.assertEqual(reindentBlock(' x'), 'x')
        self.assertEqual(reindentBlock('  x'), 'x')
        self.assertEqual(reindentBlock('\tx'), 'x')
        self.assertEqual(reindentBlock('x', ' '), ' x')
        self.assertEqual(reindentBlock('x', '\t'), '\tx')
        self.assertEqual(reindentBlock(' x', ' '), ' x')
        self.assertEqual(reindentBlock(' x', '\t'), '\tx')
        self.assertEqual(reindentBlock(' x', '  '), '  x')
        
    def testSingleLine(self):
        self.assertEqual(reindentBlock('\n'), '\n')
        self.assertEqual(reindentBlock('x\n'), 'x\n')
        self.assertEqual(reindentBlock(' x\n'), 'x\n')
        self.assertEqual(reindentBlock('  x\n'), 'x\n')
        self.assertEqual(reindentBlock('\tx\n'), 'x\n')
        self.assertEqual(reindentBlock('x\n', ' '), ' x\n')
        self.assertEqual(reindentBlock('x\n', '\t'), '\tx\n')
        self.assertEqual(reindentBlock(' x\n', ' '), ' x\n')
        self.assertEqual(reindentBlock(' x\n', '\t'), '\tx\n')
        self.assertEqual(reindentBlock(' x\n', '  '), '  x\n')
        
if __name__ == '__main__':
    unittest.main()
