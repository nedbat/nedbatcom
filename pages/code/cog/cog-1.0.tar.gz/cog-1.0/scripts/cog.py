#!/usr/bin/python
""" Cog code generation tool.
    http://nedbatchelder.com/code/cog
"""

import time
start = time.clock()

import sys
from cogapp import Cog

ret = Cog().main(sys.argv)

#print "Time: %.2f sec" % (time.clock() - start)
sys.exit(ret)
