""" HandyXml
    Make simple XML use convenient.
    http://nedbatchelder.com/code/cog

    Copyright 2004-2005, Ned Batchelder.
"""

# $Id: __init__.py 110 2005-08-27 22:35:20Z ned $

from handyxml import *
