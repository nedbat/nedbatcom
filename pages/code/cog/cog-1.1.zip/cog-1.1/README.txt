Cog code generation tool.

See http://nedbatchelder/code/cog for details.
