""" Cog code generation tool.
    http://nedbatchelder.com/code/cog
    
    Copyright 2004-2005, Ned Batchelder.
"""

# $Id: cogapp.py 31 2005-02-20 15:03:19Z ned $

import md5, os, re, string, sys, types
import imp, compiler
from cStringIO import StringIO

__all__ = ['Cog', 'CogUsageError']

__version__ = '1.4.20050218'       # History at the end of the file.

usage = """\
cog - generate code with inlined Python code.

cog [OPTIONS] [INFILE | @FILELIST] ...

INFILE is the name of an input file.
FILELIST is the name of a text file containing file names or
    other @FILELISTs.

OPTIONS:
    -c          Checksum the output to protect it against accidental change.
    -e          Warn if a file has no cog code in it.
    -I PATH     Add PATH to the list of directories for data files
                    and modules.
    -o OUTNAME  Write the output to OUTNAME.
    -r          Replace the input file with the output.
    -w CMD      Use CMD if the output file needs to be made writable.
                    A %s in the CMD will be filled with the filename.
    -x          Excise all the generated code without running the generators.
    -v          Print the version of cog and exit.
    -h          Print this help.
"""

# Get True and False right if they aren't already defined.
try:
    True, False
except NameError:
    True, False = 0==0, 0==1

# Other package modules
from whiteutils import *

class CogError(Exception):
    """ Any exception raised by Cog.
    """
    pass
    
class CogUsageError(CogError):
    """ An error in usage of command-line arguments in cog.
    """
    pass

class CogGenerator:
    """ A generator pulled from a source file.
    """
    def __init__(self, sBegin='[[[cog', sEnd=']]]'):
        self.markers = []
        self.lines = []
        self.sBegin = sBegin
        self.sEnd = sEnd
        
    def parseMarker(self, l):
        self.markers.append(l)
    
    def parseLine(self, l):
        self.lines.append(l.strip('\n'))

    def getCode(self):
        """ Extract the executable Python code from the generator.
        """
        # If the markers and lines all have the same prefix
        # (end-of-line comment chars, for example),
        # then remove it from all the lines.
        prefIn = commonPrefix(self.markers + self.lines)
        if prefIn:
            self.markers = [ l.replace(prefIn, '', 1) for l in self.markers ]
            self.lines = [ l.replace(prefIn, '', 1) for l in self.lines ]

        if len(self.markers) > 1:
            # We have a beginning and end marker
            prefIn = commonPrefix(self.markers)
            if prefIn:
                self.markers = [ l.replace(prefIn, '', 1) for l in self.markers ]
            
            # Get the code after the start marker, if there's a colon.
            sResidue = self.markers[0].split(self.sBegin, 1)[1]
            if sResidue and sResidue[0] == ':':
                self.lines.insert(0, sResidue[1:].strip())
                
            sResidue = self.markers[1].split(self.sEnd, 1)[0].strip()
            if sResidue:
                self.lines.append(sResidue)
        
        return reindentBlock(self.lines, '')
        
    def evaluate(self, cog, globals=None, fname='cog generator'):
        # figure out the right whitespace prefix for the output
        prefOut = whitePrefix(self.markers)

        intext = self.getCode()
        if not intext:
            return ''
        
        # In Python 2.2, the last line has to end in a newline.
        intext = "import cog\n" + intext + "\n"
        code = compiler.compile(intext, filename=str(fname), mode='exec')

        # Make sure the "cog" module has our state.
        cog.cogmodule.msg = self.msg
        cog.cogmodule.out = self.out
        cog.cogmodule.outl = self.outl
        
        self.outstring = ''
        if globals is None:
            globals = {}
        eval(code, globals)

        # We need to make sure that the last line in the output
        # ends with a newline, or it will be joined to the
        # end-output line, ruining cog's idempotency.
        if self.outstring and self.outstring[-1] != '\n':
            self.outstring += '\n'
            
        return reindentBlock(self.outstring, prefOut)

    def msg(self, s):
        print "Message: "+s

    def out(self, sOut='', dedent=False, trimblanklines=False):
        """ The cog.out function.
        """
        if trimblanklines and ('\n' in sOut):
            lines = sOut.split('\n')
            if lines[0].strip() == '':
                del lines[0]
            if lines and lines[-1].strip() == '':
                del lines[-1]
            sOut = '\n'.join(lines)+'\n'
        if dedent:
            sOut = reindentBlock(sOut)
        self.outstring += sOut

    def outl(self, sOut='', **kw):
        """ The cog.outl function.
        """
        self.out(sOut, **kw)
        self.out('\n')

class NumberedFileReader:
    """ A decorator for files that counts the readline()'s called.
    """
    def __init__(self, f):
        self.f = f
        self.n = 0

    def readline(self):
        l = self.f.readline()
        if l:
            self.n += 1
        return l

    def linenumber(self):
        return self.n
            
class Cog:
    """ The Cog engine.
    """
    def __init__(self):
        self.includePath = []
        self.sBeginSpec = '[[[cog'
        self.sEndSpec = ']]]'
        self.sEndOutput = '[[[end]]]'
        self.reEndOutput = re.compile(r'\[\[\[end]]](?P<hashsect> *\(checksum: (?P<hash>[a-f0-9]+)\))')
        self.sEndFormat = '[[[end]]] (checksum: %s)'
        
        # Defaults for argument values.
        self.sMakeWritableCmd = None
        self.bReplace = False
        self.bGenerate = True
        self.sOutputName = None
        self.bWarnEmpty = False
        self.bHashOutput = False
        
        self.stdout = sys.stdout
        self.stderr = sys.stderr
        
        self.installCogModule()

    def setOutput(self, stdout=None, stderr=None):
        """ Assign new files for standard our and/or standard error.
        """
        if stdout:
            self.stdout = stdout
        if stderr:
            self.stderr = stderr

    def showWarning(self, msg):
        print >>self.stdout, "Warning:", msg

    def isBeginSpecLine(self, s):
        return string.find(s, self.sBeginSpec) >= 0
    
    def isEndSpecLine(self, s):
        return string.find(s, self.sEndSpec) >= 0
    
    def isEndOutputLine(self, s):
        return string.find(s, self.sEndOutput) >= 0

    def installCogModule(self):
        """ Magic mumbo-jumbo so that imported Python modules
            can say "import cog" and get our state.
        """
        self.cogmodule = imp.new_module('cog')
        self.cogmodule.path = self.includePath
        sys.modules['cog'] = self.cogmodule
        
    def processFile(self, fIn, fOut, fname=None):
        """ Process an input file object to an output file object.
            fIn and fOut can be file objects, or file names.
        """

        sFileIn = fname or ''
        sFileOut = fname or ''
        # Convert filenames to files.
        if isinstance(fIn, types.StringTypes):
            # Open the input file.
            sFileIn = fIn
            fIn = open(fIn, 'r')
        if isinstance(fOut, types.StringTypes):
            # Open the output file.
            sFileOut = fOut
            fOut = open(fOut, 'w')

        fIn = NumberedFileReader(fIn)
        
        bSawCog = False

        self.cogmodule.inFile = sFileIn
        self.cogmodule.outFile = sFileOut

        # The globals dict we'll use for this file.
        globals = {}
        
        # loop over generator chunks
        l = fIn.readline()
        while l:
            # Find the next spec begin
            while l and not self.isBeginSpecLine(l):
                fOut.write(l)
                l = fIn.readline()
            if not l: break
            fOut.write(l)
            # l is the begin spec
            gen = CogGenerator()
            gen.parseMarker(l)
            firstLineNum = fIn.linenumber()
            self.cogmodule.firstLineNum = firstLineNum

            # If the spec begin is also a spec end, then process the single
            # line of code inside.
            if self.isEndSpecLine(l):
                beg = string.find(l, self.sBeginSpec)
                end = string.find(l, self.sEndSpec)
                if beg > end:
                    self.showWarning(
                        "cog begin and end markers inverted on line %d in %s" %
                        (firstLineNum, fname))
                else:
                    sCode = l[beg+len(self.sBeginSpec):end].strip()
                    gen.parseLine(sCode)
            else:
                # Deal with an ordinary code block.
                l = fIn.readline()
    
                # Get all the lines in the spec
                while l and not self.isEndSpecLine(l):
                    fOut.write(l)
                    gen.parseLine(l)
                    l = fIn.readline()
                if not l:
                    self.showWarning(
                        "cog block begun on line %d but not ended in %s" % 
                        (firstLineNum, fname))
                    break

                fOut.write(l)
                gen.parseMarker(l)
            
            l = fIn.readline()
            
            # Eat all the lines in the output section.  While reading past
            # them, compute the md5 hash of the old output.
            hasher = md5.new()
            while l and not self.isEndOutputLine(l):
                hasher.update(l)
                l = fIn.readline()
            curHash = hasher.hexdigest()

            # Write the output of the spec to be the new output if we're 
            # supposed to generate code.
            hasher = md5.new()
            if self.bGenerate:
                sFile = "%s+%d" % (fname, firstLineNum)
                sGen = gen.evaluate(cog=self, globals=globals, fname=sFile)
                hasher.update(sGen)
                fOut.write(sGen)
            newHash = hasher.hexdigest()
            
            bSawCog = True
            
            # Write the ending output line
            hashMatch = self.reEndOutput.search(l)
            if self.bHashOutput:
                if hashMatch:
                    oldHash = hashMatch.groupdict()['hash']
                    if oldHash != curHash:
                        raise CogError("%s(%d): Output has been edited! Delete old checksum to unprotect." % (sFileIn, fIn.linenumber()))
                    # Create a new end line with the correct hash.
                    endpieces = l.split(hashMatch.group(0), 1)
                else:
                    # There was no old hash, but we want a new hash.
                    endpieces = l.split(self.sEndOutput, 1)
                l = (self.sEndFormat % newHash).join(endpieces)
            else:
                # We don't want hashes output, so if there was one, get rid of
                # it.
                if hashMatch:
                    l = l.replace(hashMatch.groupdict()['hashsect'], '', 1)
                    
            fOut.write(l)
            l = fIn.readline()

        if not bSawCog and self.bWarnEmpty:
            self.showWarning("no cog code found in %s" % (fname,))

    def processString(self, sInput, fname=None):
        """ Process sInput as the text to cog.
            Return the cogged output as a string.
        """
        fOld = StringIO(sInput)
        fNew = StringIO()
        self.processFile(fOld, fNew, fname=fname)
        return fNew.getvalue()
        
    def replaceFile(self, sOldPath, sNewText):
        """ Replace file sOldPath with the contents sNewText
        """
        if not os.access(sOldPath, os.W_OK):
            # Need to ensure we can write.
            if self.sMakeWritableCmd:
                # Use an external command to make the file writable.
                sys.stdout.write(os.popen(self.sMakeWritableCmd % sOldPath).read())
                if not os.access(sOldPath, os.W_OK):
                    raise CogError("Couldn't make %s writable" % sOldPath)
            else:
                # Can't write!
                raise CogError("Can't overwrite %s" % sOldPath)
        f = open(sOldPath, "w")
        f.write(sNewText)
        f.close()

    def addToIncludePath(self, dirs):
        """ Add directories to the include path.
        """
        dirs = dirs.split(os.pathsep)
        self.includePath.extend(dirs)
        self.cogmodule.path = self.includePath
        sys.path.extend(dirs)
            
    def saveIncludePath(self):
        self.savedInclude = self.includePath
        self.savedSysPath = sys.path
            
    def restoreIncludePath(self):
        self.includePath = self.savedInclude
        self.cogmodule.path = self.includePath
        sys.path = self.savedSysPath

    def processOneFile(self, sFile):
        """ Process one filename through cog.
        """

        self.saveIncludePath()
        
        # Since we know where the input file came from,
        # push its directory onto the include path.
        self.addToIncludePath(os.path.dirname(sFile))

        if self.sOutputName:
            self.processFile(sFile, self.sOutputName, sFile)
        elif self.bReplace:
            # We want to replace the cog file with the output,
            # but only if they differ.
            print >>self.stdout, "Cogging %s" % sFile,
            bNeedNewline = True
            
            try:
                fOldFile = open(sFile)
                sOldText = fOldFile.read()
                fOldFile.close()
                sNewText = self.processString(sOldText, fname=sFile)
                if sOldText != sNewText:
                    print >>self.stdout, "  (changed)"
                    bNeedNewline = False
                    self.replaceFile(sFile, sNewText)
            finally:
                # The try-finally block is so we can print a partial line
                # with the name of the file, and print (changed) on the
                # same line, but also make sure to break the line before
                # any traceback.
                if bNeedNewline:
                    print >>self.stdout
        else:
            self.processFile(sFile, self.stdout, sFile)

        self.restoreIncludePath()

    def processFileList(self, sFileList):
        """ Process the files in a file list.
        """
        for l in open(sFileList).readlines():
            l = l.strip()
            if not l:
                # Ignore blank lines
                continue
            if l[0] == '#':
                # Ignore lines beginning with '#'
                continue
            self.processArgument(l)

    def processArgument(self, arg):
        """ Process one command-line filename.
        """
        if arg[0] == '@':
            if self.sOutputName:
                raise CogUsageError("Can't use -o with @file")
            self.processFileList(arg[1:])
        else:
            self.processOneFile(arg)

    def callableMain(self, argv):
        """ All of command-line cog, but in a callable form.
            This is used by main.
            argv is the equivalent of sys.argv.
        """
        import getopt
        argv0 = argv.pop(0)

        # Provide help if asked for anywhere in the command line.
        if '-?' in argv or '-h' in argv:
            print >>self.stderr, usage,
            return 2

        # Parse the command line arguments.
        try:
            opts, args = getopt.getopt(argv, 'ceI:o:rw:vx')
        except getopt.error, msg:
            raise CogUsageError(msg)

        # Handle the command line arguments.
        for o, a in opts:
            if o == '-c':
                self.bHashOutput = True
            elif o == '-e':
                self.bWarnEmpty = True
            elif o == '-I':
                self.addToIncludePath(a)
            elif o == '-o':
                self.sOutputName = a
            elif o == '-r':
                self.bReplace = True
            elif o == '-w':
                self.sMakeWritableCmd = a
            elif o == '-v':
                print >>self.stdout, "Cog version %s" % __version__
                return
            elif o == '-x':
                self.bGenerate = False
            else:
                raise CogUsageError("Don't understand argument %s" % o)

        if self.bReplace and self.sOutputName:
            raise CogUsageError("Can't use -o with -r")

        if args:
            for a in args:            
                self.processArgument(a)
        else:
            raise CogUsageError("No files to process")
        
    def main(self, argv):
        """ Handle the command-line execution for cog.
        """

        try:
            self.callableMain(argv)
            return 0
        except CogUsageError, err:
            print >>self.stderr, err
            print >>self.stderr, "(for help use -?)"
            return 2
        except:
            import traceback
            traceback.print_exc()
            return 1

# History:
# 20040210: First public version.
# 20040220: Text preceding the start and end marker are removed from Python lines.
#           -v option on the command line shows the version.
# 20040311: Make sure the last line of output is properly ended with a newline.
# 20040605: Fixed some blank line handling in cog.
#           Fixed problems with assigning to xml elements in handyxml.
# 20040621: Changed all line-ends to LF from CRLF.
# 20041002: Refactor some option handling to simplify unittesting the options.
# 20041118: cog.out and cog.outl have optional string arguments.
# 20041119: File names weren't being properly passed around for warnings, etc.
# 20041122: Added cog.firstLineNum: a property with the line number of the [[[cog line.
#           Added cog.inFile and cog.outFile: the names of the input and output file.
# 20041218: Single-line cog generators, with start marker and end marker on
#           the same line.
# 20041230: Keep a single globals dict for all the code fragments in a single
#           file so they can share state.
# 20050206: Added the -x switch to remove all generated code.
# 20050218: Now code can be on the marker lines as well.
# 20050219: Added -c switch to checksum the output so that edits can be
#           detected before they are obliterated.
