""" Test cogapp.
    http://nedbatchelder.com/code/cog
    
    Copyright 2004, Ned Batchelder.
"""

import unittest
from cogapp import Cog, CogUsageError
from whiteutils import reindentBlock
from makefiles import *
import os, path, random, StringIO, tempfile

class CogTestsInMemory(unittest.TestCase):
    """ Test cases for cogapp.Cog()
    """

    def testNoCog(self):
        strings = [
            '',
            ' ',
            ' \t \t \tx',
            'hello',
            'the cat\nin the\nhat.',
            'Horton\n\tHears A\n\t\tWho'
            ]
        for s in strings:
            self.assertEqual(Cog().processString(s), s)

    def testSimple(self):
        infile = """\
            Some text.
            //[[[cog
            import cog
            cog.outl("This is line one\\n")
            cog.outl("This is line two")
            //]]]
            gobbledegook.
            //[[[end]]]
            epilogue.
            """

        outfile = """\
            Some text.
            //[[[cog
            import cog
            cog.outl("This is line one\\n")
            cog.outl("This is line two")
            //]]]
            This is line one

            This is line two
            //[[[end]]]
            epilogue.
            """

        self.assertEqual(Cog().processString(infile), outfile)

    def testEmptyCog(self):
        # The cog clause can be totally empty.  Not sure why you'd want it,
        # but it works.
        infile = """\
            hello
            //[[[cog
            //]]]
            //[[[end]]]
            goodbye
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testMultipleCogs(self):
        # One file can have many cog chunks, even abutting each other.
        infile = """\
            //[[[cog
            cog.out("chunk1")
            //]]]
            chunk1
            //[[[end]]]
            //[[[cog
            cog.out("chunk2")
            //]]]
            chunk2
            //[[[end]]]
            between chunks
            //[[[cog
            cog.out("chunk3")
            //]]]
            chunk3
            //[[[end]]]
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testTrimBlankLines(self):
        infile = """\
            //[[[cog
            cog.out("This is line one\\n", trimblanklines=True)
            cog.out('''
                This is line two
            ''', dedent=True, trimblanklines=True)
            cog.outl("This is line three", trimblanklines=True)
            //]]]
            This is line one
            This is line two
            This is line three
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testTrimEmptyBlankLines(self):
        infile = """\
            //[[[cog
            cog.out("This is line one\\n", trimblanklines=True)
            cog.out('''
                This is line two
            ''', dedent=True, trimblanklines=True)
            cog.out('', dedent=True, trimblanklines=True)
            cog.outl("This is line three", trimblanklines=True)
            //]]]
            This is line one
            This is line two
            This is line three
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def test22EndOfLine(self):
        # In Python 2.2, this cog file was not parsing because the
        # last line is indented but didn't end with a newline.
        infile = """\
            //[[[cog
            import cog
            for i in range(3):
                cog.out("%d\\n" % i)
            //]]]
            0
            1
            2
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testIndentedCode(self):
        infile = """\
            first line
                [[[cog
                import cog
                for i in range(3):
                    cog.out("xx%d\\n" % i)
                ]]]
                xx0
                xx1
                xx2
                [[[end]]]
            last line
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testPrefixedCode(self):
        infile = """\
            --[[[cog
            --import cog
            --for i in range(3):
            --    cog.out("xx%d\\n" % i)
            --]]]
            xx0
            xx1
            xx2
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testPrefixedIndentedCode(self):
        infile = """\
            prologue
            --[[[cog
            --   import cog
            --   for i in range(3):
            --       cog.out("xy%d\\n" % i)
            --]]]
            xy0
            xy1
            xy2
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testBogusPrefixMatch(self):
        infile = """\
            prologue
            #[[[cog
                import cog
                # This comment should not be clobbered by removing the pound sign.
                for i in range(3):
                    cog.out("xy%d\\n" % i)
            #]]]
            xy0
            xy1
            xy2
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testNoFinalNewline(self):
        """ If the cog'ed output has no final newline,
            it shouldn't eat up the cog terminator.
        """
        infile = """\
            prologue
            [[[cog
                import cog
                for i in range(3):
                    cog.out("%d" % i)
            ]]]
            012
            [[[end]]]
            epilogue
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testNoOutputAtAll(self):
        """ If there is absolutely no cog output, that's ok.
        """
        infile = """\
            prologue
            [[[cog
                i = 1
            ]]]
            [[[end]]]
            epilogue
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testPurelyBlankLine(self):
        """ If there is a blank line in the cog code with no whitespace
            prefix, that should be OK.
        """

        infile = """\
            prologue
                [[[cog
                    cog.out("Hello")
            $
                    cog.out("There")
                ]]]
                HelloThere
                [[[end]]]
            epilogue
            """
            
        infile = reindentBlock(infile.replace('$', ''))
        self.assertEqual(Cog().processString(infile), infile)

    def testEmptyOutl(self):
        """ Alexander Belchenko suggested the string argument to outl should
            be optional.  Does it work?
        """
        infile = """\
            prologue
            [[[cog
                cog.outl("x")
                cog.outl()
                cog.outl("y")
                cog.outl(trimblanklines=True)
                cog.outl("z")
            ]]]
            x

            y
            
            z
            [[[end]]]
            epilogue
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testFirstLineNum(self):
        infile = """\
            fooey
            [[[cog
                cog.outl("started at line number %d" % cog.firstLineNum)
            ]]]
            started at line number 2
            [[[end]]]
            blah blah
            [[[cog
                cog.outl("and again at line %d" % cog.firstLineNum)
            ]]]
            and again at line 8
            [[[end]]]
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)
        
    def testCompactOneLineCode(self):
        infile = """\
            first line
            hey: [[[cog cog.outl("hello %d" % (3*3*3*3)) ]]] looky!
            get rid of this!
            [[[end]]]
            last line
            """
        
        outfile = """\
            first line
            hey: [[[cog cog.outl("hello %d" % (3*3*3*3)) ]]] looky!
            hello 81
            [[[end]]]
            last line
            """
        
        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), reindentBlock(outfile))
        
    def testSharingGlobals(self):
        infile = """\
            first line
            hey: [[[cog s="hey there" ]]] looky!
            [[[end]]]
            more literal junk.
            [[[cog cog.outl(s) ]]]
            [[[end]]]
            last line
            """
        
        outfile = """\
            first line
            hey: [[[cog s="hey there" ]]] looky!
            [[[end]]]
            more literal junk.
            [[[cog cog.outl(s) ]]]
            hey there
            [[[end]]]
            last line
            """
        
        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), reindentBlock(outfile))
        
class CogTestsInFiles(unittest.TestCase):

    def newCog(self):
        """ Initialize the cog members for another run.
        """
        # Create a cog engine, and catch its output.        
        self.cog = Cog()
        self.output = StringIO.StringIO()
        self.cog.setOutput(stdout=self.output, stderr=self.output)

    def setUp(self):
        # Create a temporary directory.
        self.tempdir = path.path(tempfile.gettempdir()) / ('testcog_tempdir_' + str(random.random())[2:])
        self.tempdir.mkdir()
        self.olddir = os.getcwd()
        os.chdir(self.tempdir)
        self.newCog()
        
    def tearDown(self):
        os.chdir(self.olddir)
        # Get rid of the temporary directory.
        self.tempdir.rmtree()

    def assertFilesSame(self, sFName1, sFName2):
        self.assertEqual((self.tempdir / sFName1).text(), (self.tempdir / sFName2).text())
        
    def testArgumentFailure(self):
        # Return value 2 means usage problem.
        assert(self.cog.main(['argv0', '-x']) == 2)
        output = self.output.getvalue()
        assert(output.find("option -x not recognized") >= 0)
        self.assertRaises(CogUsageError, self.cog.callableMain, (['argv0']))
        self.assertRaises(CogUsageError, self.cog.callableMain, (['argv0', '-x']))

    def testSimple(self):
        d = {
            'test.cog': """\
                // This is my C++ file.
                //[[[cog
                fnames = ['DoSomething', 'DoAnotherThing', 'DoLastThing']
                for fn in fnames:
                    cog.outl("void %s();" % fn)
                //]]]
                //[[[end]]]
                """,

            'test.out': """\
                // This is my C++ file.
                //[[[cog
                fnames = ['DoSomething', 'DoAnotherThing', 'DoLastThing']
                for fn in fnames:
                    cog.outl("void %s();" % fn)
                //]]]
                void DoSomething();
                void DoAnotherThing();
                void DoLastThing();
                //[[[end]]]
                """,
            }

        makeFiles(d, self.tempdir)
        self.cog.main(['argv0', '-r', 'test.cog'])
        self.assertFilesSame('test.cog', 'test.out')
        output = self.output.getvalue()
        assert(output.find("(changed)") >= 0)

    def testOutputFile(self):
        # -o sets the output file.
        d = {
            'test.cog': """\
                // This is my C++ file.
                //[[[cog
                fnames = ['DoSomething', 'DoAnotherThing', 'DoLastThing']
                for fn in fnames:
                    cog.outl("void %s();" % fn)
                //]]]
                //[[[end]]]
                """,

            'test.out': """\
                // This is my C++ file.
                //[[[cog
                fnames = ['DoSomething', 'DoAnotherThing', 'DoLastThing']
                for fn in fnames:
                    cog.outl("void %s();" % fn)
                //]]]
                void DoSomething();
                void DoAnotherThing();
                void DoLastThing();
                //[[[end]]]
                """,
            }

        makeFiles(d, self.tempdir)
        self.cog.main(['argv0', '-o', 'test.cogged', 'test.cog'])
        self.assertFilesSame('test.cogged', 'test.out')

    def testAtFile(self):
        d = {
            'one.cog': """\
                //[[[cog
                cog.outl("hello world")
                //]]]
                //[[[end]]]
                """,
            
            'one.out': """\
                //[[[cog
                cog.outl("hello world")
                //]]]
                hello world
                //[[[end]]]
                """,
            
            'two.cog': """\
                //[[[cog
                cog.outl("goodbye cruel world")
                //]]]
                //[[[end]]]
                """,
            
            'two.out': """\
                //[[[cog
                cog.outl("goodbye cruel world")
                //]]]
                goodbye cruel world
                //[[[end]]]
                """,
            
            'cogfiles.txt': """\
                # Please run cog
                one.cog
                
                two.cog
                """
            }

        makeFiles(d, self.tempdir)
        self.cog.main(['argv0', '-r', '@cogfiles.txt'])
        self.assertFilesSame('one.cog', 'one.out')
        self.assertFilesSame('two.cog', 'two.out')
        output = self.output.getvalue()
        assert(output.find("(changed)") >= 0)

    def testNestedAtFile(self):
        d = {
            'one.cog': """\
                //[[[cog
                cog.outl("hello world")
                //]]]
                //[[[end]]]
                """,
            
            'one.out': """\
                //[[[cog
                cog.outl("hello world")
                //]]]
                hello world
                //[[[end]]]
                """,
            
            'two.cog': """\
                //[[[cog
                cog.outl("goodbye cruel world")
                //]]]
                //[[[end]]]
                """,
            
            'two.out': """\
                //[[[cog
                cog.outl("goodbye cruel world")
                //]]]
                goodbye cruel world
                //[[[end]]]
                """,
            
            'cogfiles.txt': """\
                # Please run cog
                one.cog
                @cogfiles2.txt
                """,

            'cogfiles2.txt': """\
                # This one too, please.
                two.cog
                """,
            }

        makeFiles(d, self.tempdir)
        self.cog.main(['argv0', '-r', '@cogfiles.txt'])
        self.assertFilesSame('one.cog', 'one.out')
        self.assertFilesSame('two.cog', 'two.out')
        output = self.output.getvalue()
        assert(output.find("(changed)") >= 0)

    def testIncludePath(self):
        """ Test that -I adds include directories properly.
        """
        d = {
            'test.cog': """\
                //[[[cog
                    import mymodule
                //]]]
                //[[[end]]]
                """,
                
            'test.out': """\
                //[[[cog
                    import mymodule
                //]]]
                Hello from mymodule
                //[[[end]]]
                """,

            'include': {
                'mymodule.py': """\
                    import cog
                    cog.outl("Hello from mymodule")
                    """
                },
            }
        
        # Try it without the -I, to see that an ImportError happens.
        makeFiles(d, self.tempdir)
        self.assertRaises(ImportError, self.cog.callableMain, (['argv0', '-r', 'test.cog']))
        
        # Try it with the -I, to see that it works.
        self.cog.callableMain(['argv0', '-r', '-I', 'include', 'test.cog'])
        self.assertFilesSame('test.cog', 'test.out')

    def testSubDirectories(self):
        """ Test that relative paths on the command line work, with includes.
        """
        d = {
            'code': {
                'test.cog': """\
                    //[[[cog
                        import mysubmodule
                    //]]]
                    //[[[end]]]
                    """,
                    
                'test.out': """\
                    //[[[cog
                        import mysubmodule
                    //]]]
                    Hello from mysubmodule
                    //[[[end]]]
                    """,

                'mysubmodule.py': """\
                    import cog
                    cog.outl("Hello from mysubmodule")
                    """
                }
            }
            
        makeFiles(d, self.tempdir)
        # We should be able to invoke cog without the -I switch, and it will
        # auto-include the current directory
        self.cog.callableMain(['argv0', '-r', 'code/test.cog'])
        self.assertFilesSame('code/test.cog', 'code/test.out')

    def testWarnIfNoCogCode(self):
        # Test that the -e switch warns if there is no Cog code.
        d = {
            'with.cog': """\
                //[[[cog
                cog.outl("hello world")
                //]]]
                hello world
                //[[[end]]]
                """,
            
            'without.cog': """\
                There's no cog
                code in this file.
                """,
            }

        makeFiles(d, self.tempdir)
        self.cog.main(['argv0', '-e', 'with.cog'])
        output = self.output.getvalue()
        assert(output.find("Warning") < 0)
        self.newCog()
        self.cog.main(['argv0', '-e', 'without.cog'])
        output = self.output.getvalue()
        assert(output.find("Warning: no cog code found in without.cog") >= 0)
        self.newCog()
        self.cog.main(['argv0', 'without.cog'])
        output = self.output.getvalue()
        assert(output.find("Warning") < 0)

    def testFileNameProps(self):
        d = {
            'cog1.txt': """\
                //[[[cog
                cog.outl("This is %s in, %s out" % (cog.inFile, cog.outFile))
                //]]]
                this is cog1.txt in, cog1.txt out
                """,

            'cog1.out': """\
                //[[[cog
                cog.outl("This is %s in, %s out" % (cog.inFile, cog.outFile))
                //]]]
                This is cog1.txt in, cog1.txt out
                """,

            'cog1out.out': """\
                //[[[cog
                cog.outl("This is %s in, %s out" % (cog.inFile, cog.outFile))
                //]]]
                This is cog1.txt in, cog1out.txt out
                """,
            }

        makeFiles(d, self.tempdir)
        self.cog.callableMain(['argv0', '-r', 'cog1.txt'])
        self.assertFilesSame('cog1.txt', 'cog1.out')
        self.newCog()
        self.cog.callableMain(['argv0', '-o', 'cog1out.txt', 'cog1.txt'])
        self.assertFilesSame('cog1out.txt', 'cog1out.out')
        
    def testGlobalsDontCrossFiles(self):
        # Make sure that global values don't get shared between files.
        d = {
            'one.cog': """\
                //[[[cog s = "This was set in one.cog" ]]]
                //[[[end]]]
                //[[[cog cog.outl(s) ]]]
                //[[[end]]]
                """,
            
            'one.out': """\
                //[[[cog s = "This was set in one.cog" ]]]
                //[[[end]]]
                //[[[cog cog.outl(s) ]]]
                This was set in one.cog
                //[[[end]]]
                """,
            
            'two.cog': """\
                //[[[cog
                try:
                    cog.outl(s)
                except NameError:
                    cog.outl("s isn't set!")
                //]]]
                //[[[end]]]
                """,
            
            'two.out': """\
                //[[[cog
                try:
                    cog.outl(s)
                except NameError:
                    cog.outl("s isn't set!")
                //]]]
                s isn't set!
                //[[[end]]]
                """,
            
            'cogfiles.txt': """\
                # Please run cog
                one.cog
                
                two.cog
                """
            }

        makeFiles(d, self.tempdir)
        self.cog.main(['argv0', '-r', '@cogfiles.txt'])
        self.assertFilesSame('one.cog', 'one.out')
        self.assertFilesSame('two.cog', 'two.out')
        output = self.output.getvalue()
        assert(output.find("(changed)") >= 0)

if __name__ == '__main__':
    unittest.main()
