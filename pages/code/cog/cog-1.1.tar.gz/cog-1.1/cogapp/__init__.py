""" Cog code generation tool.
    http://nedbatchelder.com/code/cog
"""

from cogapp import *
