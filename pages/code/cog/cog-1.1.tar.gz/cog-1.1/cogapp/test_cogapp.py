""" Test cogapp.
    http://nedbatchelder.com/code/cog
"""

import unittest
from cogapp import Cog
from whiteutils import reindentBlock
from makefiles import *
import path, random, StringIO, tempfile

class CogTestsInMemory(unittest.TestCase):
    """ Test cases for cogapp.Cog()
    """

    def testNoCog(self):
        strings = [
            '',
            ' ',
            ' \t \t \tx',
            'hello',
            'the cat\nin the\nhat.',
            'Horton\n\tHears A\n\t\tWho'
            ]
        for s in strings:
            self.assertEqual(Cog().processString(s), s)

    # Test empty cog clause.
    # Test more than one cog clause.
    
    def testSimple(self):
        infile = """\
            Some text.
            //[[[cog
            import cog
            cog.outl("This is line one\\n")
            cog.outl("This is line two")
            //]]]
            gobbledegook.
            //[[[end]]]
            epilogue.
            """

        outfile = """\
            Some text.
            //[[[cog
            import cog
            cog.outl("This is line one\\n")
            cog.outl("This is line two")
            //]]]
            This is line one

            This is line two
            //[[[end]]]
            epilogue.
            """

        self.assertEqual(Cog().processString(infile), outfile)

    def testTrimBlankLines(self):
        infile = """\
            //[[[cog
            cog.out("This is line one\\n", trimblanklines=True)
            cog.out('''
                This is line two
            ''', dedent=True, trimblanklines=True)
            cog.outl("This is line three")
            //]]]
            This is line one
            This is line two
            This is line three
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def test22EndOfLine(self):
        # In Python 2.2, this cog file was not parsing because the
        # last line is indented but didn't end with a newline.
        infile = """\
            //[[[cog
            import cog
            for i in range(3):
                cog.out("%d\\n" % i)
            //]]]
            0
            1
            2
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testIndentedCode(self):
        infile = """\
            first line
                [[[cog
                import cog
                for i in range(3):
                    cog.out("xx%d\\n" % i)
                ]]]
                xx0
                xx1
                xx2
                [[[end]]]
            last line
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testPrefixedCode(self):
        infile = """\
            --[[[cog
            --import cog
            --for i in range(3):
            --    cog.out("xx%d\\n" % i)
            --]]]
            xx0
            xx1
            xx2
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testPrefixedIndentedCode(self):
        infile = """\
            prologue
            --[[[cog
            --   import cog
            --   for i in range(3):
            --       cog.out("xy%d\\n" % i)
            --]]]
            xy0
            xy1
            xy2
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testBogusPrefixMatch(self):
        infile = """\
            prologue
            #[[[cog
                import cog
                # This comment should not be clobbered by removing the pound sign.
                for i in range(3):
                    cog.out("xy%d\\n" % i)
            #]]]
            xy0
            xy1
            xy2
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testNoFinalNewline(self):
        """ If the cog'ed output has no final newline,
            it shouldn't eat up the cog terminator.
        """
        infile = """\
            prologue
            [[[cog
                import cog
                for i in range(3):
                    cog.out("%d" % i)
            ]]]
            012
            [[[end]]]
            epilogue
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

    def testNoOutputAtAll(self):
        """ If there is absolutely no cog output, that's ok.
        """
        infile = """\
            prologue
            [[[cog
                i = 1
            ]]]
            [[[end]]]
            epilogue
            """

        infile = reindentBlock(infile)
        self.assertEqual(Cog().processString(infile), infile)

class CogTestsInFiles(unittest.TestCase):

    def setUp(self):
        # Create a temporary directory.
        self.tempdir = path.path(tempfile.gettempdir()) / ('testcog_tempdir_' + str(random.random())[2:])
        self.tempdir.mkdir()
        self.cog = Cog()
        self.output = StringIO.StringIO()
        self.cog.setOutput(stdout=self.output, stderr=self.output)

    def tearDown(self):
        # Get rid of the temporary directory.
        self.tempdir.rmtree()

    def testSimple(self):
        d = {
            'test.cog': """\
                // This is my C++ file.
                //[[[cog
                fnames = ['DoSomething', 'DoAnotherThing', 'DoLastThing']
                for fn in fnames:
                    cog.outl("void %s();" % fn)
                //]]]
                //[[[end]]]
                """,

            'test.out': """\
                // This is my C++ file.
                //[[[cog
                fnames = ['DoSomething', 'DoAnotherThing', 'DoLastThing']
                for fn in fnames:
                    cog.outl("void %s();" % fn)
                //]]]
                void DoSomething();
                void DoAnotherThing();
                void DoLastThing();
                //[[[end]]]
                """,
            }

        makeFiles(d, self.tempdir)        
        self.cog.main(['argv0', '-r', self.tempdir / 'test.cog'])
        self.assertEqual((self.tempdir / 'test.cog').text(), (self.tempdir / 'test.out').text())
        output = self.output.getvalue()
        assert(output.find("(changed)") >= 0)
        
if __name__ == '__main__':
    unittest.main()
