""" HandyXml
    Make simple XML use convenient.
    http://nedbatchelder.com/code/cog

    Copyright 2004, Ned Batchelder.
"""

from handyxml import *
