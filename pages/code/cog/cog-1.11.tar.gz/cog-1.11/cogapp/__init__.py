""" Cog code generation tool.
    http://nedbatchelder.com/code/cog
    
    Copyright 2004, Ned Batchelder.
"""

from cogapp import *
