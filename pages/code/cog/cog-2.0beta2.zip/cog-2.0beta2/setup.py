#!/usr/bin/python
""" Setup.py for Cog
    http://nedbatchelder.com/code/cog

    Copyright 2004-2005, Ned Batchelder.
"""

# $Id: setup.py 113 2005-08-28 16:32:28Z ned $

from distutils.core import setup
setup(
    name = 'cog',
    version = '2.0beta2',
    url = 'http://nedbatchelder.com/code/cog',
    author = 'Ned Batchelder',
    author_email = 'ned@nedbatchelder.com',
    description = 
        'A code generator for executing Python snippets in source files.',

    packages = [
        'cogapp',
        'handyxml',
        ],

    scripts = [
        'scripts/cog.py',
        'scripts/test_cog.py',
        ],
    )
