""" Test the cogapp.makefiles modules
    http://nedbatchelder.com/code/cog
    
    Copyright 2004, Ned Batchelder.
"""

import unittest                                 # This is a unittest, so this is fundamental.
import StringIO, shutil, os, random, types, tempfile    # We need these modules to write the tests.
import makefiles

class SimpleTests(unittest.TestCase):

    def setUp(self):
        # Create a temporary directory.
        my_dir = 'testmakefiles_tempdir_' + str(random.random())[2:]
        self.tempdir = os.path.join(tempfile.gettempdir(), my_dir)
        os.mkdir(self.tempdir)

    def tearDown(self):
        # Get rid of the temporary directory.
        shutil.rmtree(self.tempdir)

    def exists(self, dname, fname):
        return os.path.exists(os.path.join(dname, fname))
    
    def testOneFile(self):
        fname = 'foo.txt'
        notfname = 'not_here.txt'
        d = { fname: "howdy" }
        assert(not self.exists(self.tempdir, fname))
        assert(not self.exists(self.tempdir, notfname))

        makefiles.makeFiles(d, self.tempdir)
        assert(self.exists(self.tempdir, fname))
        assert(not self.exists(self.tempdir, notfname))

        makefiles.removeFiles(d, self.tempdir)
        assert(not self.exists(self.tempdir, fname))
        assert(not self.exists(self.tempdir, notfname))

    def testContents(self):
        fname = 'bar.txt'
        cont0 = "I am bar.txt"
        d = { fname: cont0 }
        makefiles.makeFiles(d, self.tempdir)
        cont1 = file(os.path.join(self.tempdir, fname)).read()
        assert(cont1 == cont0)

    def testDedent(self):
        fname = 'dedent.txt'
        d = { fname: """\
                    This is dedent.txt
                    \tTabbed in.
                      spaced in.
                    OK.
                    """
              }
        makefiles.makeFiles(d, self.tempdir)
        cont = file(os.path.join(self.tempdir, fname)).read()
        assert(cont == "This is dedent.txt\n\tTabbed in.\n  spaced in.\nOK.\n")

if __name__ == '__main__':
    unittest.main()
