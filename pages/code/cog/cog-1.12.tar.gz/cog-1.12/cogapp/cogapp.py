""" Cog code generation tool.
    http://nedbatchelder.com/code/cog
    
    Copyright 2004, Ned Batchelder.
"""

import os, string, sys, types
import imp, compiler
from cStringIO import StringIO

__all__ = ['Cog']

__version__ = '1.12.20040621'       # History at the end of the file.

usage = """\
cog - generate code with inlined Python code.

cog [OPTIONS] [INFILE | @FILELIST] ...

INFILE is the name of an input file.
FILELIST is the name of a text file containing file names or
    other @FILELISTs.

OPTIONS:
    -e          Warn if a file has no cog code in it.
    -I PATH     Add PATH to the list of directories for data files
                    and modules.
    -o OUTNAME  Write the output to OUTNAME.
    -r          Replace the input file with the output.
    -w CMD      Use CMD if the output file needs to be made writable.
                    A %s in the CMD will be filled with the filename.
    -v          Print the version of cog and exit.
    -h          Print this help.
"""

# Get True and False right if they aren't already defined.
try:
    True, False
except NameError:
    True, False = 0==0, 0==1

# Other package modules
from whiteutils import *

class CogInlineTemplate:
    """ A template pulled from an inline template specification.
    """
    def __init__(self, cog):
        self.cog = cog
        self.markers = []
        self.lines = []
        
    def parseMarker(self, l):
        self.markers.append(l)
    
    def parseLine(self, l):
        self.lines.append(l.strip('\n'))

    def evaluate(self, fname='cog template'):
        # figure out the right whitespace prefix for the output
        prefOut = whitePrefix(self.markers)

        # If the markers and lines all have the same prefix
        # (end-of-line comment chars, for example),
        # then remove it from all the lines.
        prefIn = commonPrefix(self.markers + self.lines)
        if prefIn:
            self.lines = [ l.replace(prefIn, '', 1) for l in self.lines ]
            
        intext = reindentBlock(self.lines, '')
        if not intext:
            return ''
        
        # In Python 2.2, the last line has to end in a newline.
        intext = "import cog\n" + intext + "\n"
        code = compiler.compile(intext, filename=str(fname), mode='exec')

        # Make sure the "cog" module has our state.
        self.cog.cogmodule.msg = self.msg
        self.cog.cogmodule.out = self.out
        self.cog.cogmodule.outl = self.outl
        
        self.outstring = ''
        eval(code, {})

        # We need to make sure that the last line in the output
        # ends with a newline, or it will be joined to the
        # end-output line, ruining cog's idempotency.
        if self.outstring and self.outstring[-1] != '\n':
            self.outstring += '\n'
            
        return reindentBlock(self.outstring, prefOut)

    def msg(self, s):
        print "Message: "+s

    def out(self, sOut, dedent=False, trimblanklines=False):
        if trimblanklines:
            lines = sOut.split('\n')
            if lines[0].strip() == '':
                del lines[0]
            if lines and lines[-1].strip() == '':
                del lines[-1]
            sOut = '\n'.join(lines)+'\n'
        if dedent:
            sOut = reindentBlock(sOut)
        self.outstring += sOut

    def outl(self, sOut, **kw):
        self.out(sOut, **kw)
        self.out('\n')

class NumberedFileReader:
    """ A decorator for files that counts the readline()'s called.
    """
    def __init__(self, f):
        self.f = f
        self.n = 0

    def readline(self):
        l = self.f.readline()
        if l:
            self.n += 1
        return l

    def linenumber(self):
        return self.n
            
class Cog:
    """ The Cog engine.
    """
    def __init__(self):
        self.includePath = []
        self.sBeginSpec = '[[[cog'
        self.sEndSpec = ']]]'
        self.sEndOutput = '[[[end]]]'

        self.sMakeWritableCmd = None
        self.bReplace = False
        self.sOutputName = None
        self.bMultiMode = False
        self.bWarnEmpty = False

        self.stdout = sys.stdout
        self.stderr = sys.stderr
        
        self.installCogModule()

    class Usage(Exception):
        pass

    def setOutput(self, stdout=None, stderr=None):
        """ Assign new files for standard our and/or standard error.
        """
        if stdout:
            self.stdout = stdout
        if stderr:
            self.stderr = stderr

    def showWarning(self, msg):
        print >>self.stdout, "Warning:", msg

    def isBeginSpecLine(self, s):
        return string.find(s, self.sBeginSpec) >= 0
    
    def isEndSpecLine(self, s):
        return string.find(s, self.sEndSpec) >= 0
    
    def isEndOutputLine(self, s):
        return string.find(s, self.sEndOutput) >= 0

    def installCogModule(self):
        """ Magic mumbo-jumbo so that imported Python modules
            can say "import cog" and get our state.
        """
        self.cogmodule = imp.new_module('cog')
        self.cogmodule.path = self.includePath
        sys.modules['cog'] = self.cogmodule
        
    def processFile(self, fIn, fOut, fname=None):
        """ Process an input file object to an output file object.
            fIn and fOut can be file objects, or file names.
        """

        # Convert filenames to files.
        if isinstance(fIn, types.StringTypes):
            # Open the input file.
            fIn = open(fIn, 'r')
        if isinstance(fOut, types.StringTypes):
            # Open the output file.
            fOut = open(fOut, 'w')

        fIn = NumberedFileReader(fIn)
        
        bSawCog = False
        
        # loop over template chunks
        l = fIn.readline()
        while l:
            # Find the next spec begin
            while l and not self.isBeginSpecLine(l):
                fOut.write(l)
                l = fIn.readline()
            if not l: break
            fOut.write(l)
            # l is the begin spec
            tmpl = CogInlineTemplate(self)
            tmpl.parseMarker(l)
            firstLineNum = fIn.linenumber()
            
            l = fIn.readline()

            # Get all the lines in the spec
            while l and not self.isEndSpecLine(l):
                fOut.write(l)
                tmpl.parseLine(l)
                l = fIn.readline()
            if not l:
                self.showWarning("cog block begun but not ended in %s" % (fname,))
                break
            fOut.write(l)
            tmpl.parseMarker(l)
            
            l = fIn.readline()
            
            # Eat all the lines in the output section.
            while l and not self.isEndOutputLine(l):
                l = fIn.readline()

            # Write the output of the spec to be the new output
            fOut.write(tmpl.evaluate(fname="%s+%d" % (fname, firstLineNum)))
            bSawCog = True
            # Write the ending output line
            fOut.write(l)
            l = fIn.readline()

        if not bSawCog and self.bWarnEmpty:
            self.showWarning("no cog code found in %s" % (fname,))

    def processString(self, sInput, fname=None):
        """ Process sInput as the text to cog.
            Return the cogged output as a string.
        """
        fOld = StringIO(sInput)
        fNew = StringIO()
        self.processFile(fOld, fNew, fname=fname)
        return fNew.getvalue()
        
    def replaceFile(self, sOldPath, sNewText):
        """ Replace file sOldPath with the contents sNewText
        """
        if not os.access(sOldPath, os.W_OK):
            # Need to ensure we can write.
            if self.sMakeWritableCmd:
                # Use an external command to make the file writable.
                sys.stdout.write(os.popen(self.sMakeWritableCmd % sOldPath).read())
                if not os.access(sOldPath, os.W_OK):
                    raise "Couldn't make %s writable" % sOldPath
            else:
                # Can't write!
                raise "Can't overwrite %s" % sOldPath
        f = open(sOldPath, "w")
        f.write(sNewText)
        f.close()

    def addToIncludePath(self, dirs):
        """ Add directories to the include path.
        """
        dirs = dirs.split(os.pathsep)
        self.includePath.extend(dirs)
        self.cogmodule.path = self.includePath
        sys.path.extend(dirs)
            
    def saveIncludePath(self):
        self.savedInclude = self.includePath
        self.savedSysPath = sys.path
            
    def restoreIncludePath(self):
        self.includePath = self.savedInclude
        self.cogmodule.path = self.includePath
        sys.path = self.savedSysPath

    def processOneFile(self, sFile):
        """ Process one filename through cog.
        """

        self.saveIncludePath()
        
        # Since we know where the input file came from,
        # push its directory onto the include path.
        self.addToIncludePath(os.path.dirname(sFile))

        if self.sOutputName:
            self.processFile(sFile, self.sOutputName)
        elif self.bReplace:
            # We want to replace the cog file with the output,
            # but only if they differ.
            print >>self.stdout, "Cogging %s" % sFile,
            bNeedNewline = True
            
            try:
                fOldFile = open(sFile)
                sOldText = fOldFile.read()
                fOldFile.close()
                sNewText = self.processString(sOldText, fname=sFile)
                if sOldText != sNewText:
                    print >>self.stdout, "  (changed)"
                    bNeedNewline = False
                    self.replaceFile(sFile, sNewText)
            finally:
                # The try-finally block is so we can print a partial line
                # with the name of the file, and print (changed) on the
                # same line, but also make sure to break the line before
                # any traceback.
                if bNeedNewline:
                    print >>self.stdout
        else:
            self.processFile(sFile, self.stdout)

        self.restoreIncludePath()

    def processFileList(self, sFileList):
        """ Process the files in a file list.
        """
        for l in open(sFileList).readlines():
            l = l.strip()
            if not l:
                # Ignore blank lines
                continue
            if l[0] == '#':
                # Ignore lines beginning with '#'
                continue
            self.processArgument(l)

    def processArgument(self, arg):
        """ Process one command-line filename.
        """
        if arg[0] == '@':
            if self.sOutputName:
                raise Usage("Can't use -o with @file")
            self.processFileList(arg[1:])
        else:
            self.processOneFile(arg)

    def main(self, argv):
        """ Handle the command-line execution for cog.
        """

        try:
            import getopt
            argv0 = argv.pop(0)

            # Provide help if asked for anywhere in the command line.
            if '-?' in argv or '-h' in argv:
                print >>self.stderr, usage,
                return 2

            # Parse the command line arguments.
            try:
                opts, args = getopt.getopt(argv, 'eI:o:rw:v')
            except getopt.error, msg:
                raise self.Usage(msg)

            # Handle the command line arguments.            
            for o, a in opts:
                if o == '-e':
                    self.bWarnEmpty = True
                elif o == '-I':
                    self.addToIncludePath(a)
                elif o == '-o':
                    self.sOutputName = a
                elif o == '-r':
                    self.bReplace = True
                elif o == '-w':
                    self.sMakeWritableCmd = a
                elif o == '-v':
                    print >>self.stdout, "Cog version %s" % __version__
                    return 0
                else:
                    raise self.Usage("Don't understand argument %s" % o)

            if self.bReplace and self.sOutputName:
                raise self.Usage("Can't use -o with -r")

            if args:
                for a in args:            
                    self.processArgument(a)
            else:
                print >>self.stderr, usage,
                return 2

            return 0
        
        except self.Usage, err:
            print >>self.stderr, err
            print >>self.stderr, "(for help use -?)"
            return 2
        except:
            import traceback
            traceback.print_exc()
            return 1

if __name__ == '__main__':
    sys.exit(Cog().main(sys.argv))

# History:
# 20040210: First public version.
# 20040220: Text preceding the start and end marker are removed from Python lines.
#           -v option on the command line shows the version.
# 20040311: Make sure the last line of output is properly ended with a newline.
# 20040605: Fixed some blank line handling in cog.
#           Fixed problems with assigning to xml elements in handyxml.
# 20040621: Changed all line-ends to LF from CRLF.
