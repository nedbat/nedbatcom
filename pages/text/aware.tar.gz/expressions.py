import ast, collections, sys

class ExpressionFinder(ast.NodeVisitor):
    """An AST walker than finds 'safe' expressions."""

    def expressions(self, node):
        """Examine AST node `node` and return a dict mapping line numbers to lists of expressions."""
        self.exprs = collections.defaultdict(set)
        self.visit(node)
        return dict((l, sorted(e, key=len)) for l, e in self.exprs.items())

    def add_expr(self, node, expr):
        """Add the expression `expr` found in node `node`."""
        self.exprs[node.lineno].add(expr)

    ops = {
        'Add':      "+",
        'Sub':      "-",
        'Mult':     "*",
        'Div':      "/",
        'Pow':      "**",
        'Mod':      "%",
        'Eq':       "==",
        'Gt':       ">",
        'Lt':       "<",
        }

    def op(self, node):
        return self.ops.get(node.__class__.__name__)

    def generic_visit(self, node):
        return ast.NodeVisitor.generic_visit(self, node)

    def visit_Num(self, node):
        return repr(node.n)

    def visit_Str(self, node):
        return repr(node.s)

    def visit_Tuple(self, node):
        v = [self.visit(e) for e in node.elts]
        if all(v):
            if len(v) == 1:
                return "(%s,)" % (v[0],)
            else:
                return "(" + ", ".join(v) + ")"

    def visit_Name(self, node):
        self.add_expr(node, node.id)
        return node.id

    def visit_Attribute(self, node):
        val = self.visit(node.value)
        if val:
            e = "%s.%s" % (val, node.attr)
            self.add_expr(node, e)
            return e

    def visit_Subscript(self, node):
        val = self.visit(node.value)
        sli = self.visit(node.slice)
        if val and sli:
            e = "%s[%s]" % (val, sli)
            self.add_expr(node, e)
            return e

    def visit_Index(self, node):
        return self.visit(node.value)

    def visit_Slice(self, node):
        lower = self.visit(node.lower)
        upper = self.visit(node.upper)
        if node.step:
            step = self.visit(node.step)
        if lower and upper:
            e = "%s:%s" % (lower, upper)
            if node.step and step:
                e += ":%s" % (step)
            return e

    def visit_Expr(self, node):
        self.visit(node.value)

    def visit_BinOp(self, node):
        left = self.visit(node.left)
        right = self.visit(node.right)
        if left and right:
            expr = "(%s %s %s)" % (left, self.op(node.op), right)
            self.add_expr(node, expr)
            return expr

    def visit_Compare(self, node):
        left = self.visit(node.left)
        if not left:
            return
        e = "(%s" % left
        for op, comp in zip(node.ops, node.comparators):
            o = self.op(op)
            c = self.visit(comp)
            if not c:
                return
            e += " %s %s" % (o, c)
        e += ")"
        self.add_expr(node, e)
        return e

def line_expressions(filename):
    source = open(filename).read()
    node = ast.parse(source, mode="exec")
    return ExpressionFinder().expressions(node)

if __name__ == "__main__":
    import pprint
    pprint.pprint(line_expressions(sys.argv[1]))
