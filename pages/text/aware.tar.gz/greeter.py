class Greeter:
    def __init__(self, who):
        self.who = who

    def greet(self):
        print "Hello, %s!" % self.who

greeter = Greeter("world")
greeter.greet()
