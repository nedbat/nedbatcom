import inspect, linecache, sys
from expressions import line_expressions

class ShowAndTell(object):
    def __init__(self):
        self.file_expressions = {}

    def expressions(self, filename, lineno):
        if filename not in self.file_expressions:
            self.file_expressions[filename] = line_expressions(filename)
        return self.file_expressions[filename].get(lineno, [])

    def should_show_value(self, expr, val):
        if inspect.isroutine(val):
            return False
        if inspect.isclass(val):
            return False
        return True

    def trace_fn(self, frame, event, arg):
        filename = frame.f_code.co_filename
        lineno = frame.f_lineno
        src = linecache.getline(filename, lineno)[:-1]
        print "%s @ %s: %-10s | %s" % (filename, lineno, event, src)
        vals = []
        for expr in self.expressions(filename, lineno):
            try:
                val = eval(expr, frame.f_globals, frame.f_locals)
                if self.should_show_value(expr, val):
                    vals.append((expr, val))
            except:
                # All sorts of things can go wrong when trying to print these
                # expressions.  Just bail on one if it doesn't work out.
                pass
        if vals:
            print
            print "\n".join(":: %s : %r" % ev for ev in vals)
            print

        return self.trace_fn

    def execute(self, pyfile):
        """Execute `pyfile`, with a trace."""
        sys.settrace(self.trace_fn)
        try:
            exec open(pyfile) in {}
        finally:
            sys.settrace(None)
        return

if __name__ == "__main__":
    show = ShowAndTell()
    show.execute(sys.argv[1])
