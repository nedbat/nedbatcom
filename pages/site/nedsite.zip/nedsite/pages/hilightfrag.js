/*
 * Highlight the blog entry named by the fragment.
 * Ned Batchelder.
 * http://dorward.me.uk/software/frag was very helpful.
 */

function highlightFragment() {
	frag = location.hash.substring(1)
	if (frag.length > 0) {
		entry = document.getElementById(frag)
		if (entry) {
			entry.className += ' hilitefragment'
		}
	}
}

addLoadEvent(highlightFragment);
