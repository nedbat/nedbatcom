// Ned Batchelder's JavaScript helpers.
// http://nedbatchelder.com

function nospam(user,domain,args) {
	ch = String.fromCharCode;
	loc = "ma" + ch(105) + "lto" + ch(58) + user + ch(64) + domain;
	if (args) {
		loc += "?" + args;
	}
	window.location = loc;
}

function openComments(num) {
	w = 500;
	h = 650;
	t = (screen.height-h)/2;
	l = (screen.width-w)/2;
	geom = 'width='+w+',height='+h+',left='+l+',top='+t
	window.open(
		'/reactor/comment.php?entryid='+num,
		num,
		'toolbar=0,location=0,directories=0,status=1,menubar=0,scrollbars=1,resizable=1,copyhistory=0,'+geom
	)
}

// Simon Willison's page load manager method.
// http://simon.incutio.com/archive/2004/05/26/addLoadEvent

function addLoadEvent(func) {
	var oldonload = window.onload;
	if (typeof window.onload != 'function') {
		window.onload = func;
	}
	else {
		window.onload = function() {
			oldonload();
			func();
		}
	}
}
