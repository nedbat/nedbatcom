"""
xuff

Ned Batchelder, 2/2/2002
http://www.nedbatchelder.com
"""

import sys
from stellated import XuffApp

xa = XuffApp.XuffApp()
xa.main(sys.argv)
