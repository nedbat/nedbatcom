"""
XuffApp

Ned Batchelder
http://www.nedbatchelder.com

20020202 - Created
20021124 - Separated into stellated.XuffApp
"""

import os, re, shutil, string, sys, time
from xml.dom import Node
from xml.dom.ext import Printer
from xml.dom.ext.reader import PyExpat
from xml.parsers.expat import ExpatError
from xml.sax import make_parser
from xml.sax import saxutils
import Pyana
import logging
import Image
import smartypants

import walk

_verbose = 0

class Timer:
    def __init__(self):
        self.start = time.clock()

    def show(self, activity):
        now = time.clock()
        print "Time: %s: %.2f sec" % (activity, now - self.start)
        self.start = now

class XuffError:
    def __init__(self, msg):
        self.msg = msg

    def __repr__(self):
        return self.msg

def makedirs(name, mode=0777):
    """makedirs(path [, mode=0777]) -> None

    Super-mkdir; create a leaf directory and all intermediate ones.
    Works like mkdir, except that any intermediate path segment (not
    just the rightmost) will be created if it does not exist.  This is
    recursive.

    Copied from os.py and patched to allow 'foo\\.' as an arg.
    """
    if _verbose > 2: print "makedirs", name
    head, tail = os.path.split(name)
    if not tail:
        head, tail = os.path.split(head)
    if head and tail and not os.path.exists(head):
        makedirs(head, mode)
    if not os.path.exists(name):
        if _verbose > 1: print "mkdir", name
        os.mkdir(name, mode)
    else:
        if _verbose > 2: print "stat", name, os.stat(name)

def prepareForOutputFile(path):
    """
    Ensure all the dirs exist to be able to create a file, and
    remove the file if it exists to allow it to be created.
    """
    dirs = os.path.split(path)[0]
    if dirs:
        if not os.access(dirs, os.F_OK):
            makedirs(dirs)
    if os.access(path, os.F_OK):
        if _verbose > 1: print "rm", path
        os.remove(path)
    if _verbose > 0: print "writing", path

class MyXslt:
    class MyEntityResolver:
        def resolveEntity(self, public, system):
            print "resolving:", system
            return None #Pyana.URI(system)

    class MyProblemListener:
        def problem(
                self, where, classification,
                sourceNode, styleNode,
                msg, uri, line, offset):
            typeMap = {
                Pyana.eERROR:   'Error: ',
                Pyana.eWARNING: 'Warning: ',
                Pyana.eMESSAGE: 'Message: ' }

            sys.stdout.write(typeMap[classification])
            sys.stdout.write(msg)

            if classification != Pyana.eMESSAGE:
                if uri or line != -1 or offset != -1:
                    if line != -1 or offset != -1:
                        sys.stdout.write(' ["%s" (%s, %s)]' % (uri, line, offset))
                    else:
                        sys.stdout.write(' ["%s"]'% (uri,))

            sys.stdout.write("\n")

    class OneCache:
        def __init__(self):
            self.cache = ['', None]

        def get(self, key):
            if key == self.cache[0]:
                return self.cache[1]
            else:
                return None

        def put(self, key, value):
            self.cache = [key, value]

    class ManyCache:
        def __init__(self):
            self.cache = {}

        def get(self, key):
            if key in self.cache:
                return self.cache[key]
            else:
                return None

        def put(self, key, value):
            self.cache[key] = value

    def __init__(self):
        self.trans = Pyana.Transformer()
        self.xmlCache = self.OneCache()
        self.xslCache = self.OneCache()

        self.trans.setProblemListener(self.MyProblemListener())

        if _verbose > 1:
            self.setEntityResolver(MyEntityResolver())

    def transformFile(self, styf, inf, outf, params = None, moreParams = None):

        #print "Transforming %s with %s to %s" % (inf, styf, outf)
        prepareForOutputFile(outf)

        if params:
            p = params
            if moreParams:
                p = params.copy()
                p.update(moreParams)
            self.trans.setStylesheetParams(p)

        try:
            if self.xslCache is None:
                sty = Pyana.URI(styf)
            else:
                sty = self.xslCache.get(styf)
                if sty is None:
                    sty = self.trans.compileStylesheet(Pyana.URI(styf))
                    self.xslCache.put(styf, sty)

            if self.xmlCache is None:
                xml = Pyana.URI(inf)
            else:
                xml = self.xmlCache.get(inf)
                if xml is None:
                    xml = self.trans.parseSource(Pyana.URI(inf))
                    self.xmlCache.put(inf, xml)

            self.trans.transform2File(xml, sty, outf)
        except:
            etype, evalue = sys.exc_info()[:2]
            raise XuffError("XSL error: %s: %s (%s %s)" % (etype, evalue, inf, styf))

class XmlParse:
    """A simple wrapper around the PyExpat XML parser."""
    def __init__(self, uri):
        try:
            self.reader = PyExpat.Reader()
            self.doc = self.reader.fromUri(uri)
            self.documentElement = self.doc.documentElement
        except ExpatError, msg:
            raise XuffError("XML error: %s in %s" % (msg, uri))

    def release(self):
        self.reader.releaseNode(self.doc)

class XmlVisitor(Printer.PrintVisitor):
    def __init__(self, dstf):
        Printer.PrintVisitor.__init__(self, dstf, 'UTF-8')

    def visitProlog(self): pass
    def visitDocumentType(self): pass

class TreeFileWalker(walk.DirWalker):
    """
    Our specialization of DirWalker
    """
    def __init__(self, dstf):
        walk.DirWalker.__init__(self)
        self.dstf = dstf

    def startDir(self, dirName, dirPath):
        dirPath = string.replace(dirPath, '\\', '/')
        print >> self.dstf, "<directory name='%s' path='%s'>" % (dirName, dirPath)

    def endDir(self, dirName, dirPath):
        print >> self.dstf, "</directory>"

    def file(self, fileName, path, patIndex):
        if patIndex == 0:
            path = string.replace(path, '\\', '/')
            print >> self.dstf, "<file name='%s' path='%s'>" % (fileName, path)
            # open the file
            f = open(path)
            l1 = f.readline().strip()
            # Only output the first line if it is not an XML declaration.
            #if not (l1.find("<?xml ") != -1 and l1.endswith("?>")):
            #    self.dstf.write(l1)
            if l1.find("<?xml ") != -1:
                l1 = l1[l1.find("?>")+2:]
            self.dstf.write(l1)
            for l in f.readlines():
                self.dstf.write(l)
            print >> self.dstf, "</file>"
        elif patIndex == 1:
            print >> self.dstf, "<file name='%s'/>" % fileName

class XslTreeWalker(walk.DirWalker):
    """
    Specialization of DirWalker for transforming trees of files.
    """
    def __init__(self, myxslt, styf, dstpath, userXslParams):
        walk.DirWalker.__init__(self)
        self.myxslt = myxslt
        self.styf = styf
        self.dstpath = os.path.abspath(dstpath)
        self.userXslParams = userXslParams

    def forceExtension(self, ext):
        self.ext = ext

    def file(self, fileName, path, patIndex):
        dpath = path
        if self.ext:
            dpath = dpath[:string.rfind(dpath, '.')] + self.ext
        moreParams = {
            'path':     '"' + string.replace(path, '\\', '/') + '"',
            'dpath':    '"' + string.replace(dpath, '\\', '/') + '"'
            }
        dpath = os.path.join(self.dstpath, dpath)
        self.myxslt.transformFile(self.styf, path, dpath, self.userXslParams, moreParams)

class CopyFilesWalker(walk.DirWalker):
    """
    Specialization of DirWalker for copying trees of files.
    """
    def __init__(self, dstpath):
        walk.DirWalker.__init__(self)
        self.dstpath = os.path.abspath(dstpath)

    def file(self, fileName, path, patIndex):
        dpath = os.path.join(self.dstpath, path)
        prepareForOutputFile(dpath)
        shutil.copyfile(path, dpath)

class FileSplitter(saxutils.DefaultHandler):
    def __init__(self, dst='.'):
        self.xmlgen = None
        self.dirStack = [dst]

    def startElement(self, name, attrs):
        if name == 'directory':
            self.dirStack.append(os.path.join(self.dirStack[-1], attrs['name']))
        elif name == 'file':
            fpath = os.path.join(self.dirStack[-1], attrs['name'])
            prepareForOutputFile(fpath)
            self.outf = open(fpath, 'w')
            self.outf.write('<?xml version="1.0" encoding="utf-8"?>')
            self.xmlgen = saxutils.XMLGenerator(self.outf, 'utf-8')
        else:
            self.xmlgen.startElement(name, attrs)

    def endElement(self, name):
        if name == 'directory':
            self.dirStack = self.dirStack[:-1]
        elif name == 'file':
            self.xmlgen = None
            self.outf.flush()
            self.outf.close()
        else:
            self.xmlgen.endElement(name)

    def characters(self, content):
        if self.xmlgen:
            self.xmlgen.characters(content)
        elif content.strip() != '':
            print "Orphaned chars:", content

##
##  XSLT extension functions.
##

def urlquote(u):
    import urllib
    return urllib.quote(urllib.unquote(u))

def now8601():
    return time.strftime("%Y%m%dT%H%M%S")

def w3cdtf(s8601):
    sTime = time.strftime("%Y-%m-%dT%H:%M:%S", time.strptime(s8601, "%Y%m%dT%H%M%S"))
    if time.daylight:
        zsecs = time.altzone
    else:
        zsecs = time.timezone
    if zsecs < 0:
        zchar = '+'
        zsecs = -zsecs
    else:
        zchar = '-'
    zmins = zsecs/60
    zhours = zmins/60
    zmins = zmins % 60
    return "%s%s%02d:%02d" % (sTime, zchar, zhours, zmins)

def idfromtext(s):
    import urllib
    s = urllib.quote(s.strip().replace(' ', '_'))
    return s.replace('%', '_')

def lexcode(code, lang, number=False):
    import SilverCity, StringIO
    htmlgenclass = SilverCity.LanguageInfo.find_generator_by_name(lang)
    if not htmlgenclass:
        l = SilverCity.LanguageInfo.guess_languages_for_extension(lang)
        if l:
            htmlgenclass = l[0].get_default_html_generator()
    if not htmlgenclass:
        htmlgenclass = SilverCity.LanguageInfo.find_generator_by_name('null')

    # Strip a leading empty line
    if code[0] == '\n':
        code = code[1:]

    assert(htmlgenclass)
    htmlgen = htmlgenclass()
    htmlout = StringIO.StringIO()
    htmlgen.generate_html(htmlout, code)
    html = htmlout.getvalue().replace('&nbsp;', '&#160;')

    if number:
        ret = ''
        nLine = int(number)
        lines = html.split('<br/>\n')
        if not lines[-1]:
            # If the last line is blank, clobber it.
            lines = lines[:-1]
        # We want to format the lines so that they exactly fit.
        nDigits = len("%d" % len(lines))
        sFormat = '%' + str(nDigits) + 'd'
        for l in lines:
            ret += '<span class="linenumber">'
            ret += (sFormat % nLine).replace(' ', '&#160;')
            ret += '</span>'
            ret += l
            ret += '<br/>\n'
            nLine += 1
    else:
        ret = html

    return ret

imgsizecache = {}
curdir = os.getcwd()
# Yuk! Hard-coded path!
imgpath = [ curdir, os.path.join(curdir, 'pages') ]

def getImageSize(s):
    if s.startswith('http://') or s.startswith('file://'):
        return
    if not imgsizecache.has_key(s):
        img = None
        for p in imgpath:
            try:
                spath = os.path.join(p, s)
                img = Image.open(spath)
                #print "opened %r" % s
                break
            except IOError, msg:
                pass
        if img:
            imgsizecache[s] = img.size
        else:
            print "Couldn't open image %s" % s
    if imgsizecache.has_key(s):
        return imgsizecache[s]
    
def imgwidth(s):
    size = getImageSize(s)
    if size:
        return str(size[0])
    else:
        return ''

def imgheight(s):
    size = getImageSize(s)
    if size:
        return str(size[1])
    else:
        return ''

##
##  The XuffApp
##

class XuffApp:
    XuffNamespaceUri = 'http://www.stellated.com/xuff'

    def __init__(self):
        self.userXslParams = {}
        self.myxslt = MyXslt()
        self.timing = 0

    def main(self, argv):
        """
        The main entry point of the xuff application.
        """
        import getopt

        def usage():
            print "xuff [-t] [-v[v]] xuff-files ..."

        # Parse arguments.
        try:
            opts, args = getopt.getopt(argv[1:], "tv")
        except getopt.GetoptError:
            usage()
            return

        for o, a in opts:
            if o == '-v':
                global _verbose
                _verbose += 1
            elif o == '-t':
                self.timing += 1
            else:
                usage()
                return

        # Construct our log.
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("%(asctime)s.%(msecs)03d [%(levelname)s] %(message)s", "%H:%M:%S"))
        logging.getLogger().addHandler(handler)
        logging.getLogger().setLevel(logging.INFO)

        # Init our XSLT extensions.
        Pyana.installGlobalExtension(self.XuffNamespaceUri, urlquote, "urlquote")
        Pyana.installGlobalExtension(self.XuffNamespaceUri, now8601, "now")
        Pyana.installGlobalExtension(self.XuffNamespaceUri, w3cdtf, "w3cdtf")
        Pyana.installGlobalExtension(self.XuffNamespaceUri, idfromtext, "idfromtext")
        Pyana.installGlobalExtension(self.XuffNamespaceUri, lexcode, "lexcode")
        Pyana.installGlobalExtension(self.XuffNamespaceUri, imgwidth, "imgwidth")
        Pyana.installGlobalExtension(self.XuffNamespaceUri, imgheight, "imgheight")
        Pyana.installGlobalExtension(self.XuffNamespaceUri, smartypants.smartyPants, "smartypants")

        # Execute all the files.
        #try:
        for a in args:
            self.processFile(a)
        #except XuffError, msg:
        #    print "*** %s" % msg

    def isXuffElement(self, e):
        return (
            e.nodeType == Node.ELEMENT_NODE and
            e.namespaceURI == self.XuffNamespaceUri
            )

    def processFile(self, fname):
        """
        Process a single xuff file
        """
        xml = XmlParse(fname)
        for e in xml.documentElement.childNodes:
            if self.isXuffElement(e):
                handler = None
                try:
                    handler = getattr(self, 'handle_' + e.localName)
                except AttributeError:
                    print dir(self)
                    self.error("Didn't understand %s instruction" % (e.nodeName))

                if handler:
                    global _verbose
                    doVerbose = self.getAttr(e, 'verbose', 'unchanged')
                    oldVerbose = _verbose
                    if doVerbose != 'unchanged':
                        _verbose = doVerbose.lower() in ['1', 'true', 't', 'on', 'yes', 'y']
                    timer = Timer()
                    handler(e)
                    if self.timing:
                        timer.show("<%10s>" % e.nodeName)
                    _verbose = oldVerbose

        xml.release()

    def error(self, str):
        """
        Raise an error.
        """
        raise XuffError(str)

    def attrError(self, e, attrName):
        """
        The element must have the attribute.
        """
        self.error("<%s> must have %s=" % (e.nodeName, attrName))

    def getAttr(self, e, attrName, defValue=None):
        """
        Get an attribute from an element.
        """
        return e.getAttribute(attrName) or defValue or self.attrError(e, attrName)

    def getAttrNullOk(self, e, attrName):
        """
        Get an attribute from an element.
        """
        return e.getAttribute(attrName)

    def addXslParam(self, dParams, e):
        """
        Save away an XSLT param from a <param> element.
        """
        name = self.getAttr(e, 'name')
        value = self.getAttr(e, 'value')
        dParams[name] = '"' + value + '"'

    def handle_ignore(self, e):
        """
        Completely ignore this element.
        """
        pass

    def handle_message(self, e):
        """
        Write a message.
        """
        txt = self.getAttr(e, 'text')
        print txt

    def handle_treefile(self, e):
        """
        Write a model of a tree as an XML file.
        """
        out = self.getAttr(e, 'out', 'tree.xml')

        prepareForOutputFile(out)
        outf = open(out, 'w')

        print >> outf, "<?xml version='1.0'?>"
        print >> outf, "<tree>"

        if e.getAttribute('src'):
            # The element itself is the file spec.
            self.doFilesForTreeFile(e, outf)
        else:
            # Each <files> subelement is a file spec.
            for e in e.childNodes:
                if self.isXuffElement(e):
                    if e.localName == 'files':
                        self.doFilesForTreeFile(e, outf)
                    else:
                        self.error("Didn't understand %s element" % (e.nodeName))

        print >> outf, "</tree>"

    def doFilesForTreeFile(self, e, outf):
        src = self.getAttr(e, 'src')
        inc = self.getAttrNullOk(e, 'include')
        mnt = self.getAttrNullOk(e, 'mention')

        if (not inc) and (not mnt):
            mnt = '*'

        walker = TreeFileWalker(outf)

        walker.setPattern(inc, 0)
        walker.setPattern(mnt, 1)
        walker.walk(src, '.', '.')

    def handle_copy(self, e):
        """
        Copy one file.
        """
        inf = self.getAttr(e, 'in')
        outf = self.getAttr(e, 'out')
        prepareForOutputFile(outf)
        shutil.copyfile(inf, outf)

    def handle_copytree(self, e):
        """
        Copy files from one directory to another.
        """
        src = self.getAttr(e, 'src', '.')
        dst = self.getAttr(e, 'dst')
        inc = self.getAttr(e, 'include', '*.*')

        walker = CopyFilesWalker(dst)
        walker.setPattern(inc, 0)
        walker.walk(src, '.', '.')

    def handle_xsl(self, e):
        """
        Transform a single file.
        """
        styf = self.getAttr(e, 'style')
        inf = self.getAttr(e, 'in')
        outf = self.getAttr(e, 'out')

        # Each <param> subelement is a stylesheet param.
        dLocalParams = {}
        for e in e.childNodes:
            if self.isXuffElement(e):
                if e.localName == 'param':
                    self.addXslParam(dLocalParams, e)
                else:
                    self.error("Didn't understand <xsl> %s element" % (e.nodeName))

        self.myxslt.transformFile(os.path.abspath(styf), inf, outf, self.userXslParams, dLocalParams)

    def handle_xsltree(self, e):
        """
        Transform a tree of files.
        """
        styf = self.getAttr(e, 'style')
        src = self.getAttr(e, 'src', '.')
        dst = self.getAttr(e, 'dst', '.')
        inc = self.getAttr(e, 'include', '*')
        ext = self.getAttrNullOk(e, 'outext')

        walker = XslTreeWalker(self.myxslt, os.path.abspath(styf), dst, self.userXslParams)
        walker.setPattern(inc, 0)
        if ext:
            walker.forceExtension(ext)
        walker.walk(src, '.', '.')

    def handle_splitfile(self, e):
        """
        Parse an XML file, and write the files it says to.
        """
        inf = self.getAttr(e, 'in')
        dst = self.getAttr(e, 'dst', '.')

        parser = make_parser()
        parser.setContentHandler(FileSplitter(dst))
        parser.parse(inf)

    def handle_param(self, e):
        """
        Set a parameter for future XSL transforms.
        """
        self.addXslParam(self.userXslParams, e)

    def handle_del(self, e):
        """
        Remove a file.
        """
        dst = self.getAttr(e, 'dst')
        if os.access(dst, os.F_OK):
            if _verbose > 0: print "del", dst
            os.remove(dst)

    def handle_rmdir(self, e):
        """
        Remove a directory.
        """
        dst = self.getAttr(e, 'dst')
        if os.access(dst, os.F_OK):
            if _verbose > 0: print "rmdir", dst
            shutil.rmtree(dst)

    def handle_xuff(self, e):
        """
        Call another xuff script.
        """
        xuff = self.getAttr(e, 'file')
        if _verbose > 0: print "xuffing", xuff
        self.processFile(xuff)

    def handle_upload(self, e):
        """
        FTP stuff up to the server.
        """

        import stellated.FtpUpload as FtpUpload
        import socket

        host = self.getAttr(e, 'host')
        user = self.getAttr(e, 'user')
        password = self.getAttr(e, 'password')
        hostdir = self.getAttrNullOk(e, 'hostdir')
        src = self.getAttr(e, 'src', '.')
        text = self.getAttr(e, 'text')
        binary = self.getAttr(e, 'binary')
        md5file = self.getAttrNullOk(e, 'md5')

        fu = FtpUpload.FtpUpload()
        if md5file:
            fu.setMd5File(md5file)
        fu.setHost(host, user, password)
        try:
            fu.upload(hostdir=hostdir, text=text, binary=binary, src=src)
            fu.deleteOldFiles()
        except socket.error, msg:
            print "Socket error:", msg
        fu.finish()

    def handle_httpping(self, e):
        """
        Get an HTTP url, and ignore the results.
        """

        import httplib
        import urllib

        host = self.getAttr(e, 'host')
        url = self.getAttr(e, 'url')
        args = ''

        for e in e.childNodes:
            if self.isXuffElement(e):
                if e.localName == 'param':
                    if args:
                        args += '&'
                    args += urllib.urlencode({e.getAttribute('name'): e.getAttribute('value')})
                else:
                    self.error("Didn't understand %s element" % (e.nodeName))

        if args:
            url += '?' + args

        if _verbose: print 'ping host:', host
        if _verbose: print 'ping url:', url

        conn = httplib.HTTPConnection(host)
        conn.request("GET", url)
        r = conn.getresponse()
        if r.status in [200,302]:
            d = r.read()
            if _verbose:
                print 'ping returned:'
                print d
        else:
            print "HTTP ping status:", r.status, r.reason
        conn.close()

    def handle_xmlrpc(self, e):
        """
        Make an XML-RPC call.
        """

        import xmlrpclib

        url = self.getAttr(e, 'url')
        object = self.getAttr(e, 'object')
        method = self.getAttr(e, 'method')

        args = []

        for e in e.childNodes:
            if self.isXuffElement(e):
                if e.localName == 'param':
                    args.append(e.getAttribute('value'))
                else:
                    self.error("Didn't understand %s element" % (e.nodeName))

        remoteServer = xmlrpclib.Server(url)
        remoteObject = getattr(remoteServer, object)
        remoteMethod = getattr(remoteObject, method)
        if _verbose:
            print 'xml-rpc: %s %s.%s%s' % (url, object, method, args)
        dReturn = remoteMethod(*args)
        print dReturn['message']

if __name__ == '__main__':
    xuff = XuffApp()
    xuff.main(sys.argv)
